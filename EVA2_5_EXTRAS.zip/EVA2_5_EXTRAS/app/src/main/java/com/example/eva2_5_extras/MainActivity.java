package com.example.eva2_5_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Intent inenviar;
    EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text= findViewById(R.id.editText);
        inenviar = new Intent(this, Main2Activity.class);


    }

    public void enviar(View view) {
        String txtmensa = text.getText().toString();
        inenviar.putExtra("datos", txtmensa);
        inenviar.putExtra("numeros", 100);
        startActivity(inenviar);
    }
}
