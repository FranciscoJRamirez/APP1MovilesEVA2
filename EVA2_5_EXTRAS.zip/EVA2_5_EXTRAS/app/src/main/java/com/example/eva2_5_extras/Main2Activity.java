package com.example.eva2_5_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView etiq;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        etiq = findViewById(R.id.textView);
        Intent intent = getIntent();
        etiq.setText(intent.getStringExtra("datos"));
    }

    public void cerrar(View view) {
        finish();
    }
}
