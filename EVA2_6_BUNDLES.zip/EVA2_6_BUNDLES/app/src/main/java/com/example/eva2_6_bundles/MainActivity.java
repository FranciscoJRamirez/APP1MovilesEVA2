package com.example.eva2_6_bundles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    EditText ed1, ed2, ed3;
    RadioGroup radio;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.editText);
        ed2 = findViewById(R.id.editText2);
        ed3 = findViewById(R.id.editText3);
        radio = findViewById(R.id.radio);
        intent = new Intent(this, Main2Activity.class);
    }

    public void clic(View view) {
        // insertar los datos al evento
        Bundle bundle = new Bundle();
        bundle.putString("nombre", ed1.getText().toString());
        bundle.putString("apellido", ed2.getText().toString());
        int edad = Integer.parseInt(ed3.getText().toString());
        bundle.putInt("edad", edad);
        int sexo;
        if(radio.getCheckedRadioButtonId()==R.id.radioButton){
            sexo=0;
        } else if (radio.getCheckedRadioButtonId()==R.id.radioButton2){
            sexo=1;
        }else {
            sexo=2;
        }
        bundle.putInt("sexo", sexo);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
