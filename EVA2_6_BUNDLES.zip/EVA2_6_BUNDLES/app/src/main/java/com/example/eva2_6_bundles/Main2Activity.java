package com.example.eva2_6_bundles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txt = findViewById(R.id.textView2);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        txt.append(bundle.getString("nombre")+"\n");
        txt.append(bundle.getString("apellido")+"\n");
        txt.append(bundle.getInt("edad")+"\n");
        switch (bundle.getInt("sexo")){
            case 0:
                txt.append("Helicoptero no binario");
                break;
            case 1:
                txt.append("Caballo anarcocomunista alienigena");
                break;
            case 2:
                txt.append("Quien sabe");
                break;
        }
    }
}
