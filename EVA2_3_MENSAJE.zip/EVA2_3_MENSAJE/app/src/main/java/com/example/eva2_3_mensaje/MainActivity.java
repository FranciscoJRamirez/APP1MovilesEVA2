package com.example.eva2_3_mensaje;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText tele, mensa;
    Intent inmensa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tele = findViewById(R.id.tele);
        mensa = findViewById(R.id.mensaje);

    }

    public void click(View view) {
        String stel = "smsto: "+tele.getText().toString();
        inmensa = new Intent(Intent.ACTION_SENDTO, Uri.parse(stel));
        inmensa.putExtra("sms_body", mensa.getText().toString());
        startActivity(inmensa);
    }
}
