package com.example.eva2_7_activity_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    final int SECOND=14;
    Intent intent;
    TextView txtdatos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtdatos=findViewById(R.id.txtViewresult);
        intent = new Intent(this, secundaria.class);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case SECOND:
                if (resultCode == Activity.RESULT_OK){
                    //RECIBIMOS DATOS COMO RESULTADO PUEDE SER LA QUE SE MUESTRE EN EL TXTVIEW
                    txtdatos.setText(data.getStringExtra("MENSAJE"));
                }else {
                    Toast.makeText(this, "ACCION CANCELADA", Toast.LENGTH_SHORT).show();
                }
                break;

            default:
        }
    }

    public void click(View view) {
        startActivityForResult(intent,SECOND );
    }
}
