package com.example.eva2_7_activity_result;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class secundaria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundaria);
    }

    public void onclick(View view) {
        Intent indatos = new Intent();
        indatos.putExtra("MENSAJE", "HOLA, SOY POLLO");
        setResult(Activity.RESULT_OK, indatos);
        finish();
    }

    public void oncancel(View view) {
        setResult(Activity.RESULT_CANCELED);

        finish();
    }
}
