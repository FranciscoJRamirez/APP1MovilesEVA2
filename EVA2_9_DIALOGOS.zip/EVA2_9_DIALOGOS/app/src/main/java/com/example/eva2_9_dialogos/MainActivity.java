package com.example.eva2_9_dialogos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Standard(View view) {
        new AlertDialog.Builder(this).
        setTitle("Cuadro de dialogo estandar").
        setMessage("LMAO?").
        setPositiveButton("LMAO!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), "LMAO!", Toast.LENGTH_SHORT).show();
            }
        }).
        setNegativeButton("No LMAO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), "No LMAO :'(", Toast.LENGTH_SHORT).show();
            }
        }).
        setNeutralButton("MEH!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), "MEH!", Toast.LENGTH_SHORT).show();
            }
        }).create().show();
    }

    public void own(View view) {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.layout_lmao);
        final EditText txtname;
        Button btnlmao;
        txtname = dialog.findViewById(R.id.editText);
        btnlmao = dialog.findViewById(R.id.button);
        btnlmao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sCade ="Hola como estas?"+ txtname.getText().toString();
                Toast.makeText(getApplicationContext(), sCade, Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        dialog.show();

    }
}
