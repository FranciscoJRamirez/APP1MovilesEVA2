package com.example.eva2_2_intentos_llamada;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText editele;
    Intent inmarcar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editele= findViewById(R.id.editele);
    }
    public void click(View view){
        View btn = findViewById(R.id.button);
        String sTel = "tel:" + editele.getText().toString();
        if(view == btn ) {

            inmarcar = new Intent(Intent.ACTION_DIAL, Uri.parse(sTel)); //cuando pones ACTION_CALL si marcará al numero
            //que se introduzca
        }else {
            inmarcar = new Intent(Intent.ACTION_CALL, Uri.parse(sTel));
        }
        startActivity(inmarcar);
    }
}
