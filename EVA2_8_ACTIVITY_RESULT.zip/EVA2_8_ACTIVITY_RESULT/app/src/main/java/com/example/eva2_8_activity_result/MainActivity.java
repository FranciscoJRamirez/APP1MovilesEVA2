package com.example.eva2_8_activity_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    final int second=14, second2=15;
    Intent intentClima, intentRest;
    ImageView imgClima, imgrest;
    TextView txtciudad, txtclima, txttemp, txtTitle, txtDesc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intentClima = new Intent(this, classClima.class);
        intentRest = new Intent(this, classRest.class);
        imgClima = findViewById(R.id.imgClima);
        txtciudad = findViewById(R.id.txtciudad);
        txttemp = findViewById(R.id.txttemp);
        txtclima = findViewById(R.id.txtclima);
        imgrest = findViewById(R.id.imgrest);
        txtTitle = findViewById(R.id.txtTitle);
        txtDesc = findViewById(R.id.txtDesc);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle bundle = data.getExtras();
        switch (requestCode){
            case second:
                if (resultCode == Activity.RESULT_OK){
                    //RECIBIMOS DATOS COMO RESULTADO PUEDE SER LA QUE SE MUESTRE EN EL TXTVIEW
                    //Toast.makeText(this, "Holi", Toast.LENGTH_SHORT).show();
                    imgClima.setImageResource(bundle.getInt("imagen"));
                    txtciudad.setText(bundle.getString("ciudad"));
                    txttemp.setText(String.valueOf(bundle.getDouble("tempera")));
                    txtclima.setText(bundle.getString("clima"));

                }else {
                    Toast.makeText(this, "ACCION CANCELADA", Toast.LENGTH_SHORT).show();
                }
                break;
            case second2:
                if (resultCode == Activity.RESULT_OK){
                    //RECIBIMOS DATOS COMO RESULTADO PUEDE SER LA QUE SE MUESTRE EN EL TXTVIEW
                    //Toast.makeText(this, "Holi", Toast.LENGTH_SHORT).show();
                    imgrest.setImageResource(bundle.getInt("imagenr"));
                    txtTitle.setText(bundle.getString("title"));
                    txtDesc.setText(bundle.getString("desc"));

                }
                break;
            case 2000:
                if (resultCode == Activity.RESULT_OK){
                    //Toast.makeText(this, data.getDataString(), Toast.LENGTH_SHORT).show();
                    Cursor cur = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
                    if (cur.getCount() > 0) {
                        while (cur.moveToNext()) {
                            String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                            if (resultCode == Activity.RESULT_OK) {
                                //Uri contactData = data.getData();
                                Cursor c = getContentResolver().query(
                                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                        null,
                                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + id,
                                        null, null);
                                if (c.moveToFirst()) {
                                    String name = c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                    String sTel = "tel: " + name;
                                    Intent intPhone = new Intent(Intent.ACTION_DIAL, Uri.parse(sTel));
                                    startActivity(intPhone);
                                }
                            }
                        }
                    }
                }
            default:
        }
    }

    public void listaClima(View view) {

        startActivityForResult(intentClima, second);
        //codigo para llamar otro programa
        /*ComponentName cn = new ComponentName("com.example.eva1_10_lista_clima", "com.example.eva1_10_lista_clima.MainActivity");
        Intent in = new Intent(Intent.ACTION_MAIN);
        in.setComponent(cn);
        startActivityForResult(in, second);*/
    }

    public void listRes(View view) {
        startActivityForResult(intentRest, second2);
    }

    public void cont(View view) {
        Intent in = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(in, 2000);
    }

}
