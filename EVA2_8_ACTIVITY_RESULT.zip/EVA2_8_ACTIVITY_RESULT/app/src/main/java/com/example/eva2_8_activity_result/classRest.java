package com.example.eva2_8_activity_result;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class classRest extends AppCompatActivity implements AdapterView.OnItemClickListener {
    restaurante [] restaurantes={
            new restaurante(),
            new restaurante(R.drawable.hamburger, "Hamburguesas el combi","Las mas ricas del sur"),
            new restaurante(R.drawable.ensalada, "Ensaladas caseras 'Ivonne'", "mas saludable que nunca"),
            new restaurante(R.drawable.tacos, "Tacos el pelado", "los mejores tacos del estado"),
            new restaurante(R.drawable.hotdogs, "HotDogs el puerco", "quedaras como puerco")
    };
    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_rest);
        list = findViewById(R.id.list1);
        list.setAdapter(new RestAdapter(this, R.layout.layout_rest, restaurantes));
        list.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent indatos = new Intent();
        Bundle bundle = new Bundle();

        bundle.putString("title", restaurantes[i].getName());
        bundle.putInt("imagenr", restaurantes[i].getImage());
        bundle.putString("desc", restaurantes[i].getDesc());
        indatos.putExtras(bundle);
        setResult(Activity.RESULT_OK, indatos);
        finish();
    }
}
