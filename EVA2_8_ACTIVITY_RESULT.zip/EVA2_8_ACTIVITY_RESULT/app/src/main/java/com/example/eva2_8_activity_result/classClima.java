package com.example.eva2_8_activity_result;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class classClima extends AppCompatActivity implements AdapterView.OnItemClickListener {

    cilma [] cCiudades ={
            new cilma(),
            new cilma(R.drawable.atmospher, "Aldama", 25, "regular"),
            new cilma(R.drawable.cloudy, "Camargo", 25, "nublado ese"),
            new cilma(R.drawable.light_rain, "Parral", 25, "Tormenton"),
            new cilma(R.drawable.rainy, "Madera", 25, "ay mama me estoy mojando"),
            new cilma(R.drawable.snow, "Creel", 25, "nieve seca papah"),
            new cilma(R.drawable.sunny, "Jimenez", 25, "Chido"),
            new cilma(R.drawable.thunderstorm, "Juarez", 25, "Tormenton x2"),
            new cilma(R.drawable.tornado, "Hidalgo del parral", 25, "ya te cargo el payaso")

    };
    ListView lstClima;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_clima);
        lstClima = findViewById(R.id.listClima);
        lstClima.setAdapter(new ClimaAdapter(this, R.layout.layout_clima, cCiudades));
        lstClima.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent indatos = new Intent();
        Bundle bundle = new Bundle();

        bundle.putString("ciudad", cCiudades[i].getCiudad());
        bundle.putInt("imagen", cCiudades[i].getImagen());
        bundle.putDouble("tempera", cCiudades[i].getTemp());
        bundle.putString("clima", cCiudades[i].getClima());
        indatos.putExtras(bundle);
        setResult(Activity.RESULT_OK, indatos);
        finish();
    }
}
