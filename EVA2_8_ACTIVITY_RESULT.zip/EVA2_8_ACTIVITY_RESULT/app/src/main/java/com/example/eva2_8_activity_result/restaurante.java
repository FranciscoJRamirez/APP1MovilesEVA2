package com.example.eva2_8_activity_result;

public class restaurante {
    private int image;
    private String name;
    private String desc;

    public restaurante() {
        image = R.drawable.burritos;
        name = "Burritos Reyna";
        desc = "Los mejores burritos de la ciudad";
    }

    public restaurante(int image, String name, String desc) {
        this.image = image;
        this.name = name;
        this.desc = desc;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
